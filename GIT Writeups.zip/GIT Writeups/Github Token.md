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

```
https://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@github.com/xukang0/Writeups.git
```

C:\Users\Xu Kang\Documents\Obsidian Vault\GIT Writeups\HackTheBox
