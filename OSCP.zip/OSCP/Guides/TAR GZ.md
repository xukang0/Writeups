```
gunzip [file]
```

```
tar -xf [file]
```