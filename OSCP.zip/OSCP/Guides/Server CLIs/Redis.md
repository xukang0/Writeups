Redis-cli

```
redis-cli -h <host> -p <port>
```

INFO

SELECT <db_number>

KEYS (*)

1) key1
2) key2
3) key3

get key2
	it will "cat" the value of key2 out in shell