To find associated website domains

```
gobuster dns -d (inlanefreight.com) -w /usr/share/SecLists/Discovery/DNS/namelist.txt
```
