
```
cd /home/kali/Downloads
```


```
cd ../offsec
```


```
sudo openvpn universal.ovpn
```





