

```
runas /user:[USERNAME] cmd
```
