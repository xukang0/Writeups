
```
cat ~/.bash_history | sed -n '1,120p'
```