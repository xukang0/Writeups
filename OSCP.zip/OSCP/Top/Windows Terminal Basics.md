`type`
	view files
	`more` for more content
	press `Spacebar` to move by one page (flip the page) or `Enter` to move by one line.

cd
	pwd (print working directory)

dir
	ls (view child directories)
	`dir /a` - Displays hidden and system files as well.
	`dir /s` - Displays files in the current directory and all subdirectories.

`cd target_directory`
	change to any directory 

`cd ..` 
	to go up one level

ver
	To check OS version

systeminfo
	To get host name and more information

ipconfig /all
	information about network configuration

ping example.com
	ping a target

tracert example.com
	traceroute a target

nslookup example.com
	lookup the IP address of a target

netstat
	shows active connections
	netstat -h (help page)
	netstat -abon (IP no. and Service name)


mkdir directory_name
	create directory

rmdir directory_name
	remove directory

`copy` 
	command allows you to copy files

`move`
	move files 

 `del` or `erase`
	 delete a file

`tasklist`
	list the running processes 
	tasklist /? (help)

`tasklist /FI "imagename eq sshd.exe"`
	search for tasks related to `sshd.exe`

`taskkill /PID target_pid`
	 terminate any task 

`driverquery`
	displays a list of installed device drivers.
