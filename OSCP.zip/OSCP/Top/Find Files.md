```
find / -name [filename] 2>/dev/null
```

```
locate [filename]
```