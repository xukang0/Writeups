[IP]
```dataviewjs
const page = dv.page("Templater/IP");const ip = page?.IP ?? "NO IP FOUND";

const command = `${ip}`;

dv.paragraph("```bash\n" + command + "\n```");
```
Web Address
```dataviewjs
const page = dv.page("Templater/IP");const ip = page?.IP ?? "NO IP FOUND";

const command = `http://${ip}/`;

dv.paragraph("```bash\n" + command + "\n```");
```
Editing Box

```
echo "10.129.245.115 dev.devvortex.htb" | sudo tee -a /etc/hosts
```
## Provided Username

```
sudo /usr/bin/apport-cli -f -P 3019

```

## Provided Password

```
P4ntherg0t1n5r3c0n##
```
## Open Ports
---
mysql -u lewis -pP4ntherg0t1n5r3c0n##

---

## Discovered Subdomains
---
logan : tequieromucho
---

## Discovered Credentials
---
logan:$2y$10$IT4k5kmSGvHSO9d6M/1w0eYiB5Ne9XzArQRFJTGThNiy/yBtkIj12
lewis : $2y$10$6V52x.SD8Xc7hNlVwUTrI.ax4BIAYuhVBMVvnYWRceBmy8XdEzm1u

---

## Attack Angles
---


---

## User Flag

```

```

## Root Flag

```

```