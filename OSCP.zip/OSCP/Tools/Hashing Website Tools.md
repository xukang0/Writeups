MD5 Hash
https://crackstation.net

Base64 Encode and Decode
https://www.base64decode.org
https://www.base64encode.org