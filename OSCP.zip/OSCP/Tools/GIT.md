git merge -m 

git checkout b92bdd8

git reflog

git log

git branch

git add .
git commit -m "Work in progress"
git merge <branch-name>

