search -f secrets.txt

```
cd C:\\Users
```

ls