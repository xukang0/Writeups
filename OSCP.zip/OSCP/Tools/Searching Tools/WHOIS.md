```
 whois [target]
```