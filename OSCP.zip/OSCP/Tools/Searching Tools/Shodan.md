https://www.shodan.io

a search engine for devices connected to the Internet.