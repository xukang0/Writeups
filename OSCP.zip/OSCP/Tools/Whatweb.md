

```
sudo gedit /etc/hosts
```

add IP address and domain name to gedit

```
whatweb http://[domain_name]
```

Finds : Software name