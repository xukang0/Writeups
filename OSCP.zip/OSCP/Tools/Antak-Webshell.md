```
cp /usr/share/nishang/Antak-WebShell/antak.aspx ~/Desktop/[filename].aspx
```