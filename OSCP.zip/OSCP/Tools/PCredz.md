python3 -m venv venv
source venv/bin/activate
pip install Cython python-libpcap
python ./Pcredz -f demo.pcapng