```
git clone https://github.com/TheRook/subbrute.git
cd subbrute
```

```
python3 subbrute.py -p inlanefreight.htb -s names.txt -r resolvers.txt
```
