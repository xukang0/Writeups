Dirsearch -u [URL Link]

Dirserach -u -http://10.10.10.10

Dirsearch --help
