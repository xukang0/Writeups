sudo gedit /etc/proxychains4.conf

msfconsole
set proxies http:127.0.0.1:8080