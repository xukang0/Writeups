```
echo -n "Academy#2025" | sha1sum
```