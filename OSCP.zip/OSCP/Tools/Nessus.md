
```
sudo systemctl start nessusd.service
```

```
https://localhost:8834
```

SA2C-JPRQ-CKR4-6FQA-89L5