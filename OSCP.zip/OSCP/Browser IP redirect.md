If typing IP in browser gives redirect but says page not found,

try adding (IP) unika.htb to

etc/hosts

```
sudo gedit etc/hosts
```

Add (IP) unika.htb to below line

This is to tell server specifically that "unika.htb" belongs to (IP)