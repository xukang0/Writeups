[IP]
```dataviewjs
const page = dv.page("Templater/IP");const ip = page?.IP ?? "NO IP FOUND";

const command = `${ip}`;

dv.paragraph("```bash\n" + command + "\n```");
```
Web Address
```dataviewjs
const page = dv.page("Templater/IP");const ip = page?.IP ?? "NO IP FOUND";

const command = `http://${ip}/`;

dv.paragraph("```bash\n" + command + "\n```");
```
Editing Box

```

```
## Provided Username

```

```

## Provided Password

```

```
## Open Ports
---


---

## Discovered Subdomains
---


---

## Discovered Credentials
---


---

## Attack Angles
---


---

## User Flag

```

```

## Root Flag

```

```