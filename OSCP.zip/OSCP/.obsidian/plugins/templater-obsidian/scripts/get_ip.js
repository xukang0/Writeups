module.exports = async (tp) => {
    const file = await app.vault.getAbstractFileByPath("Templates/IP.md");
    const content = await app.vault.read(file);
    const match = content.match(/IP::\s*(.+)/);
    return match ? match[1].trim() : "IP_NOT_FOUND";
};
