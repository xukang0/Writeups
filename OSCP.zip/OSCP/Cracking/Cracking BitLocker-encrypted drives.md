```
bitlocker2john -i Backup.vhd > backup.hashes
```

```
grep "bitlocker\$0" backup.hashes > backup.hash
```

```
cat backup.hash
```

John the ripper crack

```
hashcat -a 0 -m 22100 '$bitlocker$0$16$02b329c0453b9273f2fc1b927443b5fe$1048576$12$00b0a67f961dd80103000000$60$d59f37e70696f7eab6b8f95ae93bd53f3f7067d5e33c0394b3d8e2d1fdb885cb86c1b978f6cc12ed26de0889cd2196b0510bbcd2a8c89187ba8ec54f' /usr/share/wordlists/rockyou.txt
```