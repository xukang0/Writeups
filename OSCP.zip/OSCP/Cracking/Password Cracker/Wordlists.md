Rockyou
```
usr/share/wordlists/rockyou.txt
```

FFUZ

```
/usr/share/seclists/Discovery/Web-Content/directory-list-2.3-small.txt
```

```
/usr/share/seclists/Discovery/Web-Content/common.txt
```

Web extension
```
/usr/share/seclists/Discovery/Web-Content/web-extensions.txt
```

Subdomains

```
/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt
```

Parameter

```
/usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt
```