look at any ports that might be listening locally
```
ss -tlpn
```