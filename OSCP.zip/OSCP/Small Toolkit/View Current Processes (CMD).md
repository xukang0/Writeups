```cmd
ps -ux
```
