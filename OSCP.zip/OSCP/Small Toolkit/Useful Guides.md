Apache Tomcat
https://hackviser.com/tactics/pentesting/services/tomcat