When some credentials are obtained Bloodhound can be an very useful tool. 
Install using pip install bloodhound / apt install bloodhound
Start neo4j console: sudo neo4j console
start ./ or bloodhound 

First run the bloodhound-python module to get data:
`./bloodhound.py -u support -p#00^BlackKnight -d blackfield.local -ns 10.10.10.192 -c DcOnly`

Then upload data 