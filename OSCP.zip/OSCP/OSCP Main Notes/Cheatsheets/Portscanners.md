### Nmap ###
`$ nmap -v -A -p- $IP` 

### Rust Scan ###
https://github.com/RustScan/RustScan
`rustscan $IP -- -A `



https://github.com/p3ta00/SusSCAN