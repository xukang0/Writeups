Git dumper -> https://github.com/arthaud/git-dumper

LaTeX known working generator:
`script$\lstinputlisting{/etc/passwd}$`