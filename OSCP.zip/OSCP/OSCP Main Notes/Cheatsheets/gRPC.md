use grpcurl to gain inital access 
use #grpcui https://github.com/fullstorydev/grpcui/releases/tag/v1.4.1 to get an http version of the app
`./grpcui -plaintext 10.10.11.214:50051`
`grpcurl -plaintext 10.10.11.214:50051 list`
