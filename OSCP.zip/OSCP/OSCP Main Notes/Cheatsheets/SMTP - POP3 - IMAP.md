Username enumeration:
``
`smtp-user-enum -U /usr/share/seclists/Usernames/xato-net-10-million-usernames.txt -t oscp.exam`**