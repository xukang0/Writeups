### Linux Rootkits ###
Clean up rootkit (userland) -> https://github.com/bluedragonsecurity/bds_userland